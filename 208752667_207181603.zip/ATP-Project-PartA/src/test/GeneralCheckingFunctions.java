package test;

public class GeneralCheckingFunctions {
    public static String getGithubLink() {
        return "https://github.com/yoavzelinger/ATP-Project";
    }
    public static boolean check3DMaze() {
        return true;
    }
}
