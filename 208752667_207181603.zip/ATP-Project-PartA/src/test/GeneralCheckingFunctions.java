package test;

public class GeneralCheckingFunctions {
    public static String getGithubLink() {
        return "https://github.com/Yoav-Itzik-org/ATP-Project";
    }
    public static boolean check3DMaze() {
        return true;
    }
}
